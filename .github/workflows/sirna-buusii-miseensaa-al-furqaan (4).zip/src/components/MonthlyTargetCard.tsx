import React, { useState, useEffect } from 'react';
import {
  Target,
  Edit3,
  Check,
  X,
  RotateCcw,
  TrendingUp,
  CheckCircle2,
} from 'lucide-react';
import { formatCurrencyETB } from '../utils/ethiopianCalendar';

interface MonthlyGoalProgressBarProps {
  currentAmount: number;
  goalAmount: number;
  monthLabel: string;
  receiptCount: number;
}

export const MonthlyGoalProgressBar: React.FC<MonthlyGoalProgressBarProps> = ({
  currentAmount,
  goalAmount,
  monthLabel,
  receiptCount,
}) => {
  const rawPercent = goalAmount > 0 ? Math.round((currentAmount / goalAmount) * 100) : 0;
  const clampedPercent = Math.min(Math.max(rawPercent, 0), 100);
  const isGoalMet = goalAmount > 0 && currentAmount >= goalAmount;
  const remainingETB = Math.max(goalAmount - currentAmount, 0);
  const surplusETB = Math.max(currentAmount - goalAmount, 0);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            Buusii Ji’a {monthLabel} (Current Contributions)
          </div>
          <div className="flex items-baseline gap-2 mt-0.5 flex-wrap">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#0B1F3A] dark:text-white font-mono">
              {formatCurrencyETB(currentAmount)}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
              / {goalAmount > 0 ? formatCurrencyETB(goalAmount) : 'Galmi hin qophoofne'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-extrabold font-mono border ${
              isGoalMet
                ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                : 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800'
            }`}
          >
            {isGoalMet ? (
              <CheckCircle2 className="w-3.5 h-3.5" />
            ) : (
              <TrendingUp className="w-3.5 h-3.5" />
            )}
            <span>{rawPercent}%</span>
          </span>
        </div>
      </div>

      {/* Progress Bar Track */}
      <div className="relative">
        <div
          role="progressbar"
          aria-label={`Monthly contribution goal progress for ${monthLabel}`}
          aria-valuenow={clampedPercent}
          aria-valuemin={0}
          aria-valuemax={100}
          className="w-full h-4 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden border border-slate-200/80 dark:border-slate-700/80 p-0.5"
        >
          <div
            className={`h-full rounded-full transition-all duration-500 ease-out ${
              isGoalMet
                ? 'bg-emerald-600 dark:bg-emerald-500'
                : rawPercent >= 65
                ? 'bg-[#1D4ED8] dark:bg-blue-500'
                : 'bg-[#0B1F3A] dark:bg-blue-600'
            }`}
            style={{ width: `${clampedPercent}%` }}
          />
        </div>

        {/* Milestone Scale */}
        <div className="flex justify-between text-[10px] font-mono text-slate-400 mt-1.5 px-0.5">
          <span>0%</span>
          <span>25%</span>
          <span>50%</span>
          <span>75%</span>
          <span>100%</span>
        </div>
      </div>

      {/* Footer Insight Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 text-xs">
        <div className="text-slate-600 dark:text-slate-300">
          {goalAmount <= 0 ? (
            <span>Galma ji’aa qopheessuuf "Galma Jijjiiri" tuqaa.</span>
          ) : isGoalMet ? (
            <span className="font-semibold text-emerald-700 dark:text-emerald-400">
              Galmi ji’aa milkaa’inaan guutameera! Daballii: +{formatCurrencyETB(surplusETB)}
            </span>
          ) : (
            <span>
              Galma gahuuf kan hafe:{' '}
              <strong className="font-mono text-[#0B1F3A] dark:text-white">
                {formatCurrencyETB(remainingETB)}
              </strong>
            </span>
          )}
        </div>
        <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
          Nagahee {receiptCount} ji’a kana galmaa’e
        </div>
      </div>
    </div>
  );
};

interface MonthlyTargetCardProps {
  currentMonthTotal: number;
  currentMonthReceiptCount: number;
  monthLabel: string;
  ethiopianYear: number;
  customMonthlyTargetETB: number;
  totalMonthlyPledged: number;
  isAdmin: boolean;
  onSaveMonthlyTarget: (targetETB: number) => Promise<void>;
}

export const MonthlyTargetCard: React.FC<MonthlyTargetCardProps> = ({
  currentMonthTotal,
  currentMonthReceiptCount,
  monthLabel,
  ethiopianYear,
  customMonthlyTargetETB,
  totalMonthlyPledged,
  isAdmin,
  onSaveMonthlyTarget,
}) => {
  const hasCustomTarget = customMonthlyTargetETB > 0;
  const effectiveGoal = hasCustomTarget ? customMonthlyTargetETB : totalMonthlyPledged;

  const [isEditing, setIsEditing] = useState(false);
  const [draftTarget, setDraftTarget] = useState<string>(
    String(hasCustomTarget ? customMonthlyTargetETB : totalMonthlyPledged || '')
  );
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );

  useEffect(() => {
    if (!isEditing) {
      setDraftTarget(String(hasCustomTarget ? customMonthlyTargetETB : totalMonthlyPledged || ''));
    }
  }, [customMonthlyTargetETB, totalMonthlyPledged, hasCustomTarget, isEditing]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numericTarget = Number(draftTarget);
    if (Number.isNaN(numericTarget) || numericTarget < 0) {
      setSaveMessage({ type: 'error', text: 'Maaloo lakkoofsa sirrii (>= 0) galchaa.' });
      return;
    }

    try {
      setIsSaving(true);
      setSaveMessage(null);
      await onSaveMonthlyTarget(numericTarget);
      setIsEditing(false);
      setSaveMessage({
        type: 'success',
        text:
          numericTarget > 0
            ? `Galmi ji’aa gara ${formatCurrencyETB(numericTarget)} tti haaromfameera.`
            : 'Galmi ji’aa gara waadaa miseensotaa (auto) tti deebifameera.',
      });
    } catch (err: any) {
      setSaveMessage({
        type: 'error',
        text: err?.message || 'Galma ji’aa olkaa’uun hin danda’amne.',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetToPledged = async () => {
    try {
      setIsSaving(true);
      setSaveMessage(null);
      await onSaveMonthlyTarget(0);
      setIsEditing(false);
      setSaveMessage({
        type: 'success',
        text: 'Galmi ji’aa gara waadaa miseensotaa (Auto Pledge Sum) tti deebifameera.',
      });
    } catch (err: any) {
      setSaveMessage({
        type: 'error',
        text: err?.message || 'Deebisuun hin danda’amne.',
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <section aria-label="Monthly Financial Target Progress">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-blue-700 dark:text-blue-400 flex items-center gap-1.5">
              <Target className="w-3.5 h-3.5" />
              <span>Galma Faayinaansii Ji’aa · Monthly Financial Target</span>
            </div>
            <h3 className="text-base sm:text-lg font-bold text-[#0B1F3A] dark:text-white mt-0.5">
              Raawwii Galma Ji’a {monthLabel} {ethiopianYear}
            </h3>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-[11px] font-semibold text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
              {hasCustomTarget
                ? `Galma Qophaa’e (Custom): ${formatCurrencyETB(customMonthlyTargetETB)}`
                : `Waadaa Miseensotaa (Pledges): ${formatCurrencyETB(totalMonthlyPledged)}`}
            </span>

            {isAdmin && !isEditing && (
              <button
                type="button"
                onClick={() => {
                  setSaveMessage(null);
                  setIsEditing(true);
                }}
                className="px-3 py-1.5 bg-[#0B1F3A] hover:bg-blue-900 dark:bg-blue-700 dark:hover:bg-blue-600 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Galma Jijjiiri (Set Target)</span>
              </button>
            )}
          </div>
        </div>

        {/* Inline Target Editor Form (Admin Only) */}
        {isAdmin && isEditing && (
          <form
            onSubmit={handleSubmit}
            className="mt-4 p-4 rounded-xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/70 flex flex-col md:flex-row md:items-end gap-3"
          >
            <div className="flex-1">
              <label className="block text-xs font-bold text-[#0B1F3A] dark:text-blue-200 mb-1">
                Galma Ji’aa Haaraa (Monthly Financial Target in ETB)
              </label>
              <input
                type="number"
                min={0}
                step="any"
                required
                value={draftTarget}
                onChange={(e) => setDraftTarget(e.target.value)}
                placeholder="fkn. 50000"
                className="w-full px-3.5 py-2 text-sm font-mono font-bold bg-white dark:bg-slate-900 border border-blue-200 dark:border-blue-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                Waadaan miseensota socho’oo ammaa: <strong className="font-mono">{formatCurrencyETB(totalMonthlyPledged)}</strong>. Yoo 0 galchitan waadaa miseensotaa fayyadama.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                type="submit"
                disabled={isSaving}
                className="px-4 py-2 bg-[#0B1F3A] hover:bg-blue-900 dark:bg-blue-700 dark:hover:bg-blue-600 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition disabled:opacity-50"
              >
                <Check className="w-3.5 h-3.5" />
                <span>{isSaving ? 'Olkaa’amaa...' : 'Galma Olkaa’i'}</span>
              </button>

              {hasCustomTarget && (
                <button
                  type="button"
                  onClick={handleResetToPledged}
                  disabled={isSaving}
                  title="Reset to active member pledge sum"
                  className="px-3 py-2 bg-white dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Auto (Pledges)</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setIsEditing(false)}
                disabled={isSaving}
                className="px-3 py-2 bg-white dark:bg-slate-800 hover:bg-slate-100 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1 transition"
              >
                <X className="w-3.5 h-3.5" />
                <span>Dhiisi</span>
              </button>
            </div>
          </form>
        )}

        {saveMessage && (
          <div
            className={`mt-4 px-3.5 py-2.5 rounded-xl text-xs font-medium border ${
              saveMessage.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                : 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800'
            }`}
          >
            {saveMessage.text}
          </div>
        )}

        <div className="pt-5">
          <MonthlyGoalProgressBar
            currentAmount={currentMonthTotal}
            goalAmount={effectiveGoal}
            monthLabel={`${monthLabel} ${ethiopianYear}`}
            receiptCount={currentMonthReceiptCount}
          />
        </div>
      </div>
    </section>
  );
};
