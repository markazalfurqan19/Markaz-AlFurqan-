import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        onClick={install}
        className={`flex items-center justify-center gap-1.5 rounded-xl bg-[#0B1F3A] hover:bg-blue-900 dark:bg-blue-700 dark:hover:bg-blue-600 text-white font-bold shadow-xs transition cursor-pointer ${
          compact ? 'px-3 py-1.5 text-[11px]' : 'w-full px-3.5 py-2.5 text-xs'
        }`}
        title="Install Al-Furqaan App on your device for offline access"
      >
        <Download className="w-3.5 h-3.5 shrink-0" />
        <span>App Buusi (Install)</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className={`flex items-center justify-center gap-1.5 rounded-xl border border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-950/60 text-[#0B1F3A] dark:text-blue-200 hover:bg-blue-100 font-semibold transition cursor-pointer ${
            compact ? 'px-2.5 py-1.5 text-[11px]' : 'w-full px-3.5 py-2 text-xs'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5 shrink-0" />
          <span>Install App (iOS)</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
            <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-xl">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-base font-bold text-[#0B1F3A] dark:text-white flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-blue-700 dark:text-blue-400" />
                  iPhone / iPad irratti Fe’i
                </h3>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed space-y-2">
                1. Safari keessatti mallattoo <strong>Share</strong> (arrow ol-ba’u) cuqaasaa.
                <br />
                2. Gadi siqaa fi <strong>Add to Home Screen</strong> filadhaa.
              </p>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full rounded-xl bg-[#0B1F3A] text-white py-2.5 text-xs font-bold hover:bg-blue-900 transition"
              >
                Cufi (Close)
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
