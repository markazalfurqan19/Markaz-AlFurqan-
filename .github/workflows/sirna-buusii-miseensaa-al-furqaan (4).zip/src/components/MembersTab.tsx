import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  X,
  Shield,
  Lock,
  MessageCircle,
  WifiOff,
  Database,
  ChevronDown,
  ChevronRight,
  Calendar,
  Receipt,
} from 'lucide-react';
import { Member, Contribution, Language } from '../types';
import {
  ETHIOPIAN_MONTHS,
  formatCurrencyETB,
  generateMemberId,
  getCurrentEthiopianYearAndMonth,
} from '../utils/ethiopianCalendar';
import { TRANSLATIONS } from '../utils/translations';
import { createPledgeReminderWhatsAppMessage, sendViaWhatsApp } from '../utils/whatsapp';
import { AlFurqaanLogo } from './AlFurqaanLogo';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

interface MembersTabProps {
  members: Member[];
  contributions: Contribution[];
  lang: Language;
  isAdmin: boolean;
  currentUserId: string;
  currentUserEmail: string;
  onAddMember: (member: Omit<Member, 'id'>) => Promise<void>;
  onRecordPaymentForMember: (member: Member) => void;
  onSendReminderForMember: (member: Member) => void;
  isShowingOfflineCache?: boolean;
  lastCachedAt?: string | null;
}

export const MembersTab: React.FC<MembersTabProps> = ({
  members,
  contributions,
  lang,
  isAdmin,
  currentUserId,
  currentUserEmail,
  onAddMember,
  onRecordPaymentForMember,
  onSendReminderForMember,
  isShowingOfflineCache = false,
  lastCachedAt = null,
}) => {
  const t = TRANSLATIONS[lang] || TRANSLATIONS.om;
  const currentEth = getCurrentEthiopianYearAndMonth();
  const isOnline = useOnlineStatus();

  const [search, setSearch] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedPaymentFilter, setSelectedPaymentFilter] = useState<'all' | 'unpaid' | 'paid'>('all');
  const [expandedMemberKeys, setExpandedMemberKeys] = useState<Record<string, boolean>>({});
  const [selectedHistoryYearByMember, setSelectedHistoryYearByMember] = useState<Record<string, number>>({});
  const [showAllHistoryByMember, setShowAllHistoryByMember] = useState<Record<string, boolean>>({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // New member form state
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const [monthlyPledgeETB, setMonthlyPledgeETB] = useState<number>(1000);
  const [city, setCity] = useState('Finfinnee / Addis Ababa');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');

  // RBAC Filtering: If not admin, regular user ONLY sees members that they registered!
  const userVisibleMembers = isAdmin
    ? members
    : members.filter(
        (m) =>
          m.createdBy === currentUserId ||
          m.createdBy === currentUserEmail ||
          (m.createdBy && m.createdBy.toLowerCase() === currentUserEmail.toLowerCase())
      );

  // Valid (non-voided) contributions & current Ethiopian month paid member set
  const validContributions = contributions.filter((c) => c.status !== 'voided');

  const paidThisMonthIds = new Set(
    validContributions
      .filter(
        (c) =>
          c.ethiopianMonth === currentEth.monthKey &&
          c.ethiopianYear === currentEth.year
      )
      .map((c) => c.memberId)
  );

  const unpaidActiveCount = userVisibleMembers.filter(
    (m) => m.status === 'active' && !paidThisMonthIds.has(m.memberId)
  ).length;

  // Calculate total contributed & grouped history per member
  const monthOrderMap: Record<string, number> = {};
  ETHIOPIAN_MONTHS.forEach((m, idx) => {
    monthOrderMap[m.key] = idx;
  });

  const memberTotalPaid: Record<string, number> = {};
  const memberAllContributions: Record<string, Contribution[]> = {};

  contributions.forEach((c) => {
    const key = c.memberId;
    if (!memberAllContributions[key]) memberAllContributions[key] = [];
    memberAllContributions[key].push(c);
    if (c.status !== 'voided') {
      memberTotalPaid[key] = (memberTotalPaid[key] || 0) + (c.amountETB || 0);
    }
  });

  Object.keys(memberAllContributions).forEach((key) => {
    memberAllContributions[key].sort((a, b) => {
      if ((b.ethiopianYear || 0) !== (a.ethiopianYear || 0)) {
        return (b.ethiopianYear || 0) - (a.ethiopianYear || 0);
      }
      const mDiff = (monthOrderMap[b.ethiopianMonth] ?? -1) - (monthOrderMap[a.ethiopianMonth] ?? -1);
      if (mDiff !== 0) return mDiff;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  });

  const toggleExpandMember = (memberKey: string) => {
    setExpandedMemberKeys((prev) => ({ ...prev, [memberKey]: !prev[memberKey] }));
  };

  const filteredMembers = userVisibleMembers.filter((m) => {
    const query = search.trim().toLowerCase();
    const normalizedQueryDigits = query.replace(/[\s\-()+]/g, '');
    const normalizedPhoneDigits = (m.phoneNumber || '').replace(/[\s\-()+]/g, '');

    const matchesSearch =
      !query ||
      m.fullName.toLowerCase().includes(query) ||
      m.memberId.toLowerCase().includes(query) ||
      (m.phoneNumber && m.phoneNumber.toLowerCase().includes(query)) ||
      (normalizedQueryDigits.length > 0 && normalizedPhoneDigits.includes(normalizedQueryDigits)) ||
      (m.email && m.email.toLowerCase().includes(query));

    const matchesStatus = selectedStatus === 'all' || m.status === selectedStatus;
    const isUnpaidCurrentMonth = m.status === 'active' && !paidThisMonthIds.has(m.memberId);
    const matchesPayment =
      selectedPaymentFilter === 'all' ||
      (selectedPaymentFilter === 'unpaid' && isUnpaidCurrentMonth) ||
      (selectedPaymentFilter === 'paid' && paidThisMonthIds.has(m.memberId));

    return matchesSearch && matchesStatus && matchesPayment;
  });

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !phoneNumber) return;

    try {
      setIsSubmitting(true);
      const nextSeq = members.length + 1;
      const memberCode = generateMemberId(nextSeq);

      await onAddMember({
        fullName,
        phoneNumber,
        email: email || undefined,
        memberId: memberCode,
        monthlyPledgeETB: Number(monthlyPledgeETB) || 0,
        status,
        city,
        createdBy: currentUserId || currentUserEmail,
        createdAt: new Date().toISOString(),
      });

      setIsModalOpen(false);
      setFullName('');
      setPhoneNumber('');
      setEmail('');
      setMonthlyPledgeETB(1000);
    } catch (err: any) {
      alert(err?.message || 'Failed to add member');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-xl font-bold text-[#0B1F3A] dark:text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-700 dark:text-blue-400" />
              {t.members} ({filteredMembers.length})
            </h2>
            {isAdmin ? (
              <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-bold bg-blue-50 dark:bg-blue-950/60 text-[#0B1F3A] dark:text-blue-300 border border-blue-200 dark:border-blue-800 flex items-center gap-1">
                <Shield className="w-3 h-3 text-blue-700 dark:text-blue-400" /> All Center Members (Admin)
              </span>
            ) : (
              <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-bold bg-blue-50 dark:bg-blue-950/60 text-[#0B1F3A] dark:text-blue-300 border border-blue-200 dark:border-blue-800 flex items-center gap-1">
                <Lock className="w-3 h-3 text-blue-700 dark:text-blue-400" /> Miseensota Ati Galmeessite Qofa
              </span>
            )}
            {unpaidActiveCount > 0 && (
              <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-semibold bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 border border-amber-200/80 dark:border-amber-800/60 inline-flex items-center gap-1">
                <AlertTriangle className="w-3 h-3 text-amber-600 dark:text-amber-400" />
                {unpaidActiveCount} · {currentEth.monthNameOm} Hin Kaffalamne
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {isAdmin
              ? `Miseensota buusii ji'aa Al-Furqaan kaffalanii fi waadaa galan hunda · Ji'a Ammaa: ${currentEth.monthNameOm} ${currentEth.year}`
              : 'Miseensa haaraa galmeessuu dandeessa; miseensonni ati galmeessite qofti asirratti mul\'atu.'}
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2.5 bg-[#0B1F3A] hover:bg-blue-900 dark:bg-blue-700 dark:hover:bg-blue-600 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition shrink-0"
        >
          <Plus className="w-4 h-4" />
          {t.addMember}
        </button>
      </div>

      {/* Offline Cached Member List Notice */}
      {(!isOnline || isShowingOfflineCache) && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-4 py-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/70 text-xs text-amber-900 dark:text-amber-200">
          <div className="flex items-center gap-2 font-semibold">
            <WifiOff className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
            <span>
              Haala Offline — Tarreen miseensotaa {userVisibleMembers.length} kuusaa offline (Service Worker Cache) irraa mul’achaa jira.
            </span>
          </div>
          {lastCachedAt && (
            <span className="inline-flex items-center gap-1 text-[11px] font-mono text-amber-700 dark:text-amber-300 shrink-0">
              <Database className="w-3.5 h-3.5" />
              Last synced: {new Date(lastCachedAt).toLocaleString()}
            </span>
          )}
        </div>
      )}

      {/* Filters & Search */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            aria-label="Search members by name or phone number"
            placeholder="Maqaa ykn lakk. bilbilaa dhaan barbaadi (Search by name or phone)..."
            className="w-full pl-10 pr-9 py-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
          {search && (
            <button
              type="button"
              onClick={() => setSearch('')}
              title="Clear search"
              aria-label="Clear search"
              className="absolute right-2.5 top-2 p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Current Month Payment Filter */}
          <div className="flex items-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-1 text-[11px] font-semibold">
            <button
              onClick={() => setSelectedPaymentFilter('all')}
              className={`px-2.5 py-1.5 rounded-lg transition ${
                selectedPaymentFilter === 'all'
                  ? 'bg-[#0B1F3A] dark:bg-blue-700 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              Hunda
            </button>
            <button
              onClick={() => setSelectedPaymentFilter('unpaid')}
              className={`px-2.5 py-1.5 rounded-lg transition flex items-center gap-1 ${
                selectedPaymentFilter === 'unpaid'
                  ? 'bg-amber-600 text-white'
                  : 'text-amber-700 dark:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/40'
              }`}
            >
              <AlertTriangle className="w-3 h-3" />
              Hin Kaffalle ({unpaidActiveCount})
            </button>
            <button
              onClick={() => setSelectedPaymentFilter('paid')}
              className={`px-2.5 py-1.5 rounded-lg transition ${
                selectedPaymentFilter === 'paid'
                  ? 'bg-blue-700 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              Kaffalame
            </button>
          </div>

          {/* Status filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2.5 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
          >
            <option value="all">{t.allStatuses}</option>
            <option value="active">{t.active}</option>
            <option value="inactive">{t.inactive}</option>
          </select>
        </div>
      </div>

      {/* Expandable Members Table with Inline Recent Contribution History */}
      {filteredMembers.length > 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 text-[11px] uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  <th className="py-3.5 pl-4 pr-2 w-10">
                    <span className="sr-only">Expand</span>
                  </th>
                  <th className="py-3.5 px-3 font-bold">Miseensa (Member)</th>
                  <th className="py-3.5 px-3 font-bold">Bilbila & Bakka</th>
                  <th className="py-3.5 px-3 font-bold">Waadaa Ji’aa</th>
                  <th className="py-3.5 px-3 font-bold">Waliigala Kaffale</th>
                  <th className="py-3.5 px-3 font-bold">Haala Ji’a Ammaa</th>
                  <th className="py-3.5 pl-3 pr-4 font-bold text-right">Tarkaanfii</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredMembers.map((m) => {
                  const rowKey = m.id || m.memberId;
                  const isExpanded = Boolean(expandedMemberKeys[rowKey]);
                  const totalPaid = memberTotalPaid[m.memberId] || 0;
                  const memberHistory = memberAllContributions[m.memberId] || [];
                  const validMemberHistory = memberHistory.filter((c) => c.status !== 'voided');
                  const hasPaidCurrentMonth = paidThisMonthIds.has(m.memberId);
                  const isUnpaidThisMonth = m.status === 'active' && !hasPaidCurrentMonth;

                  const availableYears = Array.from(
                    new Set([currentEth.year, ...validMemberHistory.map((c) => c.ethiopianYear)])
                  ).sort((a, b) => b - a);
                  const activeHistoryYear =
                    selectedHistoryYearByMember[rowKey] ?? availableYears[0] ?? currentEth.year;

                  const paidMonthsAmountMap: Record<string, number> = {};
                  validMemberHistory
                    .filter((c) => c.ethiopianYear === activeHistoryYear)
                    .forEach((c) => {
                      paidMonthsAmountMap[c.ethiopianMonth] =
                        (paidMonthsAmountMap[c.ethiopianMonth] || 0) + (c.amountETB || 0);
                    });
                  const paidMonthsCountInYear = Object.keys(paidMonthsAmountMap).length;

                  const showAll = Boolean(showAllHistoryByMember[rowKey]);
                  const visibleHistory = showAll ? memberHistory : memberHistory.slice(0, 8);

                  return (
                    <React.Fragment key={rowKey}>
                      <tr
                        className={`transition-colors ${
                          isExpanded
                            ? 'bg-blue-50/50 dark:bg-blue-950/20'
                            : isUnpaidThisMonth
                            ? 'bg-amber-50/30 dark:bg-slate-900 hover:bg-amber-50/60 dark:hover:bg-slate-800/50'
                            : 'hover:bg-slate-50/80 dark:hover:bg-slate-800/40'
                        }`}
                      >
                        <td className="py-3.5 pl-4 pr-2 align-middle">
                          <button
                            type="button"
                            onClick={() => toggleExpandMember(rowKey)}
                            aria-expanded={isExpanded}
                            aria-label={`${isExpanded ? 'Collapse' : 'Expand'} contribution history for ${m.fullName}`}
                            title="Seenaa kaffaltii ji’ootaa ilaali (View contribution history)"
                            className={`p-1.5 rounded-lg border transition ${
                              isExpanded
                                ? 'bg-[#0B1F3A] text-white border-[#0B1F3A] dark:bg-blue-700 dark:border-blue-700'
                                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-blue-400 hover:text-blue-700'
                            }`}
                          >
                            {isExpanded ? (
                              <ChevronDown className="w-4 h-4" />
                            ) : (
                              <ChevronRight className="w-4 h-4" />
                            )}
                          </button>
                        </td>

                        <td className="py-3.5 px-3 align-middle">
                          <button
                            type="button"
                            onClick={() => toggleExpandMember(rowKey)}
                            className="text-left group"
                          >
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-bold text-sm text-[#0B1F3A] dark:text-white group-hover:text-blue-700 dark:group-hover:text-blue-400 transition">
                                {m.fullName}
                              </span>
                              <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950/60 text-[#0B1F3A] dark:text-blue-300 border border-blue-200/70 dark:border-blue-800">
                                {m.memberId}
                              </span>
                              <span
                                className={`text-[10px] font-semibold uppercase ${
                                  m.status === 'active'
                                    ? 'text-blue-700 dark:text-blue-400'
                                    : 'text-slate-500'
                                }`}
                              >
                                {m.status}
                              </span>
                            </div>
                            {m.email && (
                              <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-1">
                                <Mail className="w-3 h-3 text-slate-400" />
                                <span className="truncate max-w-[220px]">{m.email}</span>
                              </div>
                            )}
                          </button>
                        </td>

                        <td className="py-3.5 px-3 align-middle">
                          <div className="flex items-center gap-1.5 font-mono text-slate-700 dark:text-slate-200 font-semibold">
                            <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span>{m.phoneNumber}</span>
                          </div>
                          {m.city && (
                            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                              <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                              <span>{m.city}</span>
                            </div>
                          )}
                        </td>

                        <td className="py-3.5 px-3 align-middle font-mono font-bold text-blue-700 dark:text-blue-400 whitespace-nowrap">
                          {formatCurrencyETB(m.monthlyPledgeETB)}
                        </td>

                        <td className="py-3.5 px-3 align-middle whitespace-nowrap">
                          <div className="font-mono font-bold text-[#0B1F3A] dark:text-white">
                            {formatCurrencyETB(totalPaid)}
                          </div>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                            {validMemberHistory.length} kaffaltii
                          </div>
                        </td>

                        <td className="py-3.5 px-3 align-middle whitespace-nowrap">
                          {isUnpaidThisMonth ? (
                            <span
                              title={`${currentEth.monthNameOm} ${currentEth.year} kaffaltiin hin galmoofne`}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-amber-100/90 dark:bg-amber-950/80 text-amber-900 dark:text-amber-200 border border-amber-300/80 dark:border-amber-700/60"
                            >
                              <AlertTriangle className="w-3 h-3 text-amber-600 dark:text-amber-400 shrink-0" />
                              <span>Hin kaffalamne</span>
                            </span>
                          ) : hasPaidCurrentMonth ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-blue-50 dark:bg-blue-950/50 text-blue-800 dark:text-blue-300 border border-blue-200/80 dark:border-blue-800/60">
                              <CheckCircle2 className="w-3 h-3 text-blue-700 dark:text-blue-400 shrink-0" />
                              <span>{currentEth.monthNameOm}</span>
                            </span>
                          ) : (
                            <span className="text-[11px] text-slate-400 uppercase">{m.status}</span>
                          )}
                        </td>

                        <td className="py-3.5 pl-3 pr-4 align-middle text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => onRecordPaymentForMember(m)}
                              className="px-3 py-1.5 bg-[#0B1F3A] hover:bg-blue-900 dark:bg-blue-700 dark:hover:bg-blue-600 text-white font-semibold text-xs rounded-xl inline-flex items-center gap-1.5 transition"
                            >
                              <CreditCard className="w-3.5 h-3.5" />
                              <span>Kaffaltii</span>
                            </button>

                            {m.phoneNumber && (
                              <button
                                type="button"
                                onClick={() => {
                                  const msg = createPledgeReminderWhatsAppMessage(
                                    m,
                                    currentEth.monthNameOm,
                                    currentEth.year
                                  );
                                  sendViaWhatsApp(m.phoneNumber, msg);
                                }}
                                title="Yaadachiisa Buusii WhatsApp dhaan Ergi"
                                className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-xl border border-slate-200 dark:border-slate-700 transition"
                              >
                                <MessageCircle className="w-4 h-4 text-emerald-600" />
                              </button>
                            )}

                            {m.email && (
                              <button
                                type="button"
                                onClick={() => onSendReminderForMember(m)}
                                title="Yaadachiisa Imeeliin Ergi"
                                className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 dark:hover:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 transition"
                              >
                                <Mail className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>

                      {/* Expanded Row: Paid Months Overview & Recent Contribution History Table */}
                      {isExpanded && (
                        <tr className="bg-slate-50/90 dark:bg-slate-950/50">
                          <td colSpan={7} className="p-4 sm:p-5 border-t border-blue-200/70 dark:border-blue-900/50">
                            <div className="space-y-4">
                              {/* Paid Months Matrix Header & Year Switcher */}
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-200/80 dark:border-slate-800">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <Calendar className="w-4 h-4 text-blue-700 dark:text-blue-400" />
                                  <h4 className="text-xs font-bold text-[#0B1F3A] dark:text-white">
                                    Ji’oota Kaffalaman — Bara {activeHistoryYear} E.C. ({paidMonthsCountInYear}/13 ji’oota)
                                  </h4>
                                  {isAdmin && m.createdBy && (
                                    <span className="text-[10px] text-slate-400 font-mono">
                                      · Galmeessaa: {m.createdBy}
                                    </span>
                                  )}
                                </div>

                                <div className="flex items-center gap-2">
                                  <label className="text-[11px] text-slate-500 dark:text-slate-400 font-semibold">
                                    Waggaa:
                                  </label>
                                  <select
                                    value={activeHistoryYear}
                                    onChange={(e) =>
                                      setSelectedHistoryYearByMember((prev) => ({
                                        ...prev,
                                        [rowKey]: Number(e.target.value),
                                      }))
                                    }
                                    className="text-xs font-mono font-bold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1 text-[#0B1F3A] dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600"
                                  >
                                    {availableYears.map((yr) => (
                                      <option key={yr} value={yr}>
                                        {yr} E.C.
                                      </option>
                                    ))}
                                  </select>
                                </div>
                              </div>

                              {/* 13 Ethiopian Months Paid/Unpaid Badges */}
                              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 gap-2">
                                {ETHIOPIAN_MONTHS.map((ethM) => {
                                  const paidAmt = paidMonthsAmountMap[ethM.key] || 0;
                                  const isMonthPaid = paidAmt > 0;
                                  const shortLabel = ethM.om.split(' ')[0];
                                  return (
                                    <div
                                      key={ethM.key}
                                      title={`${ethM.om} ${activeHistoryYear}: ${
                                        isMonthPaid ? formatCurrencyETB(paidAmt) : 'Hin kaffalamne'
                                      }`}
                                      className={`px-2 py-1.5 rounded-lg border text-center transition ${
                                        isMonthPaid
                                          ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-300 dark:border-blue-700 text-[#0B1F3A] dark:text-blue-200'
                                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400 dark:text-slate-500'
                                      }`}
                                    >
                                      <div className="flex items-center justify-center gap-1 text-[10px] font-bold truncate">
                                        {isMonthPaid && (
                                          <CheckCircle2 className="w-3 h-3 text-blue-700 dark:text-blue-400 shrink-0" />
                                        )}
                                        <span className="truncate">{shortLabel}</span>
                                      </div>
                                      <div className="text-[9px] font-mono mt-0.5 truncate">
                                        {isMonthPaid ? formatCurrencyETB(paidAmt) : '—'}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>

                              {/* Recent Contribution History Table */}
                              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                                <div className="px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                                  <div className="flex items-center gap-2 text-xs font-bold text-[#0B1F3A] dark:text-white">
                                    <Receipt className="w-3.5 h-3.5 text-blue-700 dark:text-blue-400" />
                                    <span>
                                      Seenaa Buusii Dhiyoo (Recent Contribution History · {memberHistory.length})
                                    </span>
                                  </div>
                                  {memberHistory.length > 8 && (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        setShowAllHistoryByMember((prev) => ({
                                          ...prev,
                                          [rowKey]: !prev[rowKey],
                                        }))
                                      }
                                      className="text-[11px] font-semibold text-blue-700 dark:text-blue-400 hover:underline"
                                    >
                                      {showAll
                                        ? 'Xiqqeessi (Show Recent 8)'
                                        : `Hunda Agarsiisi (${memberHistory.length})`}
                                    </button>
                                  )}
                                </div>

                                {visibleHistory.length > 0 ? (
                                  <div className="overflow-x-auto">
                                    <table className="w-full text-left text-xs">
                                      <thead>
                                        <tr className="border-b border-slate-100 dark:border-slate-800 text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400">
                                          <th className="py-2 px-4 font-semibold">Guyyaa (Date)</th>
                                          <th className="py-2 px-3 font-semibold">Lakk. Nagahee</th>
                                          <th className="py-2 px-3 font-semibold">Ji’a & Waggaa</th>
                                          <th className="py-2 px-3 font-semibold">Hanga (ETB)</th>
                                          <th className="py-2 px-3 font-semibold">Karaa</th>
                                          <th className="py-2 px-4 font-semibold text-right">Haala</th>
                                        </tr>
                                      </thead>
                                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                                        {visibleHistory.map((c) => {
                                          const ethObj = ETHIOPIAN_MONTHS.find(
                                            (em) => em.key === c.ethiopianMonth
                                          );
                                          const monthLabel = ethObj
                                            ? ethObj.om.split(' ')[0]
                                            : c.ethiopianMonth;
                                          const isVoided = c.status === 'voided';
                                          return (
                                            <tr
                                              key={c.id || c.receiptNumber}
                                              className={
                                                isVoided
                                                  ? 'opacity-55 bg-slate-50/50 dark:bg-slate-900'
                                                  : 'hover:bg-slate-50/70 dark:hover:bg-slate-800/30'
                                              }
                                            >
                                              <td className="py-2 px-4 font-mono text-[11px] text-slate-500 dark:text-slate-400 whitespace-nowrap">
                                                {c.createdAt
                                                  ? new Date(c.createdAt).toLocaleDateString()
                                                  : '—'}
                                              </td>
                                              <td className="py-2 px-3 font-mono font-semibold text-[#0B1F3A] dark:text-slate-200 whitespace-nowrap">
                                                {c.receiptNumber}
                                              </td>
                                              <td className="py-2 px-3 font-semibold text-slate-700 dark:text-slate-200 whitespace-nowrap">
                                                {monthLabel} {c.ethiopianYear}
                                              </td>
                                              <td
                                                className={`py-2 px-3 font-mono font-bold whitespace-nowrap ${
                                                  isVoided
                                                    ? 'line-through text-slate-400'
                                                    : 'text-blue-700 dark:text-blue-400'
                                                }`}
                                              >
                                                {formatCurrencyETB(c.amountETB)}
                                              </td>
                                              <td className="py-2 px-3 uppercase text-[10px] font-bold text-slate-500 dark:text-slate-400 whitespace-nowrap">
                                                {c.paymentMethod}
                                              </td>
                                              <td className="py-2 px-4 text-right whitespace-nowrap">
                                                <span
                                                  className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                                                    isVoided
                                                      ? 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
                                                      : c.status === 'pending'
                                                      ? 'bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800'
                                                      : 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                                                  }`}
                                                >
                                                  {c.status}
                                                </span>
                                              </td>
                                            </tr>
                                          );
                                        })}
                                      </tbody>
                                    </table>
                                  </div>
                                ) : (
                                  <div className="px-4 py-6 text-center text-xs text-slate-500 dark:text-slate-400 flex flex-col sm:flex-row items-center justify-center gap-3">
                                    <span>Miseensa kanaaf seenaan kaffaltii hin galmoofne.</span>
                                    <button
                                      type="button"
                                      onClick={() => onRecordPaymentForMember(m)}
                                      className="px-3 py-1.5 bg-[#0B1F3A] hover:bg-blue-900 dark:bg-blue-700 text-white rounded-lg text-[11px] font-semibold inline-flex items-center gap-1"
                                    >
                                      <CreditCard className="w-3 h-3" />
                                      Kaffaltii Jalqabaa Galmeessi
                                    </button>
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="text-center py-16 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6">
          <AlertCircle className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          <h3 className="text-sm font-bold text-[#0B1F3A] dark:text-slate-200">Miseensi hin argamne</h3>
          <p className="text-xs text-slate-500 mt-1">
            {isAdmin
              ? 'Maqaa ykn lakkoofsa bilbilaa barbaadan sirreessaa yaalaa.'
              : 'Miseensi ati galmeessite hin jiru. "Miseensa Haaraa Galmeessi" tuquun jalqabi.'}
          </p>
        </div>
      )}

      {/* Add Member Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl relative my-8">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-3">
              <AlFurqaanLogo size="sm" />
              <div>
                <h3 className="text-lg font-bold text-[#0B1F3A] dark:text-white leading-tight">
                  {t.addMember}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Odeeffannoo miseensa haaraa galmeessaa
                </p>
              </div>
            </div>

            <form onSubmit={handleCreate} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Maqaa Guutuu (Full Name) *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="fkn. Ahmedin Jemal Ali"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                    Lakk. Bilbilaa *
                  </label>
                  <input
                    type="text"
                    required
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="+251 91 ..."
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                    Imeelii (Gmail / Email)
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="example@gmail.com"
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                    Buusii Waadaa Ji’atti (ETB) *
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={monthlyPledgeETB}
                    onChange={(e) => setMonthlyPledgeETB(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-600 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                    Magaalaa / Bakka Jireenyaa
                  </label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="fkn. Finfinnee"
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-600"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-xl font-semibold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 bg-[#0B1F3A] hover:bg-blue-900 dark:bg-blue-700 dark:hover:bg-blue-600 text-white rounded-xl font-semibold shadow-xs transition disabled:opacity-50"
                >
                  {isSubmitting ? 'Galmaa’aa Jira...' : t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
