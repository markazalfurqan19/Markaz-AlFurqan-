import React from 'react';
import { WifiOff, Database } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

interface OfflineIndicatorProps {
  cachedMembersCount: number;
  lastCachedAt: string | null;
}

export const OfflineIndicator: React.FC<OfflineIndicatorProps> = ({
  cachedMembersCount,
  lastCachedAt,
}) => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex items-center gap-2.5 rounded-xl bg-[#0B1F3A] border border-amber-400/60 px-3.5 py-2.5 text-xs font-semibold text-white shadow-xl">
      <WifiOff className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
      <div>
        <div className="leading-tight">Haala Offline — Intarneetiin Hin Jiru</div>
        <div className="text-[10px] text-blue-200 flex items-center gap-1 mt-0.5">
          <Database className="w-3 h-3" />
          <span>
            Tarree miseensotaa {cachedMembersCount} kuusaa irraa argama
            {lastCachedAt
              ? ` (${new Date(lastCachedAt).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })})`
              : ''}
          </span>
        </div>
      </div>
    </div>
  );
};
