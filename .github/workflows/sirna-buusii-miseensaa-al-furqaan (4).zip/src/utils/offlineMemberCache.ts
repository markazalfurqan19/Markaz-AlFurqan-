import { Member } from '../types';

const MEMBER_CACHE_NAME = 'al-furqaan-member-list-v1';
const CACHE_STORAGE_PREFIX = '/offline-cache/members-';
const LOCAL_STORAGE_PREFIX = 'al_furqaan_offline_members_';
const LAST_UID_KEY = 'al_furqaan_last_cached_uid';

export interface CachedMemberSnapshot {
  userId: string;
  cachedAt: string;
  count: number;
  members: Member[];
}

function cacheRequestUrl(userId: string): string {
  return `${CACHE_STORAGE_PREFIX}${encodeURIComponent(userId)}.json`;
}

/**
 * Persists the current member list inside Service Worker Cache Storage
 * (with a localStorage fallback) so members remain viewable offline.
 */
export async function saveMemberListToOfflineCache(
  userId: string,
  members: Member[]
): Promise<string> {
  if (!userId) return '';

  const cachedAt = new Date().toISOString();
  const snapshot: CachedMemberSnapshot = {
    userId,
    cachedAt,
    count: members.length,
    members,
  };
  const serialized = JSON.stringify(snapshot);

  try {
    if (typeof window !== 'undefined' && 'caches' in window) {
      const cache = await window.caches.open(MEMBER_CACHE_NAME);
      const response = new Response(serialized, {
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'X-Offline-Cached-At': cachedAt,
        },
      });
      await cache.put(cacheRequestUrl(userId), response);
    }
  } catch (err) {
    console.warn('CacheStorage member write fallback:', err);
  }

  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(`${LOCAL_STORAGE_PREFIX}${userId}`, serialized);
      window.localStorage.setItem(LAST_UID_KEY, userId);
    }
  } catch (err) {
    console.warn('localStorage member cache skipped:', err);
  }

  return cachedAt;
}

/**
 * Reads the offline-cached member list from Service Worker Cache Storage
 * or localStorage fallback when operating in poor/offline network conditions.
 */
export async function loadMemberListFromOfflineCache(
  userId?: string
): Promise<CachedMemberSnapshot | null> {
  const targetUid =
    userId ||
    (typeof window !== 'undefined' && window.localStorage
      ? window.localStorage.getItem(LAST_UID_KEY) || ''
      : '');

  if (!targetUid) return null;

  try {
    if (typeof window !== 'undefined' && 'caches' in window) {
      const cache = await window.caches.open(MEMBER_CACHE_NAME);
      const matched = await cache.match(cacheRequestUrl(targetUid));
      if (matched) {
        const data = (await matched.json()) as CachedMemberSnapshot;
        if (Array.isArray(data?.members)) {
          return data;
        }
      }
    }
  } catch (err) {
    console.warn('CacheStorage member read error:', err);
  }

  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = window.localStorage.getItem(`${LOCAL_STORAGE_PREFIX}${targetUid}`);
      if (raw) {
        const parsed = JSON.parse(raw) as CachedMemberSnapshot;
        if (Array.isArray(parsed?.members)) {
          return parsed;
        }
      }
    }
  } catch (err) {
    console.warn('localStorage member cache parse error:', err);
  }

  return null;
}

/**
 * Clears cached member snapshots upon explicit user sign-out to protect PII.
 */
export async function clearOfflineMemberCache(userId?: string): Promise<void> {
  try {
    if (typeof window !== 'undefined' && 'caches' in window) {
      if (userId) {
        const cache = await window.caches.open(MEMBER_CACHE_NAME);
        await cache.delete(cacheRequestUrl(userId));
      } else {
        await window.caches.delete(MEMBER_CACHE_NAME);
      }
    }
  } catch (err) {
    console.warn('CacheStorage clear error:', err);
  }

  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      if (userId) {
        window.localStorage.removeItem(`${LOCAL_STORAGE_PREFIX}${userId}`);
      }
      window.localStorage.removeItem(LAST_UID_KEY);
    }
  } catch (err) {
    console.warn('localStorage clear error:', err);
  }
}
