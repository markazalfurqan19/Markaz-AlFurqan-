import { createRoot } from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';

registerSW({
  immediate: true,
  onOfflineReady() {
    console.info('Al-Furqaan PWA offline shell is ready.');
  },
});

createRoot(document.getElementById('root')!).render(<App />);
